File
====

HTML5 FileAPI `File` for Node.js

See <https://github.com/node-file-api/file-api>
