"use strict";
/**
 * Types extracted from https://discord.com/developers/docs/topics/oauth2
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=oauth2.js.map