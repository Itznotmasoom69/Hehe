"use strict";
/**
 * Types extracted from https://discord.com/developers/docs/resources/template
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=template.js.map